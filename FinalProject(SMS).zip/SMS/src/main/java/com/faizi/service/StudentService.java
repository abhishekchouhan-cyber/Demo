package com.faizi.service;

import java.util.List;

import com.faizi.entity.Enrollment;
import com.faizi.entity.Student;

public interface StudentService {
	Student createStudent(Student student);
	List<Student> getAllStudents();
	Student updateStudent(String studentID,Student UpdatedStudent);
	String deleteStudent(String studentID);
	Student getStudentByID(String studentID);
	List<Enrollment> getEnrollmentDetailsByCourseId(String courseId);
	Enrollment studentEnrollment(Enrollment enrollment);
	
}
