package com.faizi.service;

import com.faizi.entity.Feedback;
import com.faizi.entity.Student;



public interface FeedBackService {
	Student getStudent(String studentID);
	Feedback createFeedback(Feedback feedback);
}
