package com.faizi.service;

import com.faizi.entity.Course;

public interface CourseService {
	Course createCourse(Course course);	
	Course getCourse(String courseID);
}
