package com.faizi.service;

import com.faizi.entity.Instructor;

public interface InstructorService {
Instructor createInstructor(Instructor instructor);
Instructor getInstructor(String instructorId);
}
