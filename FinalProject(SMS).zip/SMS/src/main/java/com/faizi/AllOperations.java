package com.faizi;

import java.util.List;
import java.util.Scanner;
import com.faizi.entity.Course;
import com.faizi.entity.Enrollment;
import com.faizi.entity.Feedback;
import com.faizi.entity.Instructor;
import com.faizi.entity.Student;
import com.faizi.exception.ResourceNotFoundException;
import com.faizi.service.CourseService;
import com.faizi.service.FeedBackService;
import com.faizi.service.InstructorService;
import com.faizi.service.StudentService;
import com.faizi.serviceImpl.CourseServiceImple;
import com.faizi.serviceImpl.FeedBackServiceImpl;
import com.faizi.serviceImpl.InstructorServiceImpl;
import com.faizi.serviceImpl.StudentServiceImpl;
import com.faizi.MainOperation.*;

public class AllOperations {
	static Scanner sc = new Scanner(System.in);
	static StudentService studentService = new StudentServiceImpl();
	static InstructorService instructorService = new InstructorServiceImpl();
	static FeedBackService feedBackService = new FeedBackServiceImpl();
	static CourseService courseService = new CourseServiceImple();

// student level operations 
	public static void studentOperations() {
		while (true) {
			System.out.println("Press 1.Add Student Details\nPress 2.Retrieve All Student Data\n"
					+ "Press 3.Update Student Data\nPress 4.Delete Student Data\n"
					+ "Press 5.To Go back to the main menu");
			int input = sc.nextInt();
			switch (input) {
			case 1:
				Student s = StudentInput();
				Student savedStudent = studentService.createStudent(s);
				System.out.println("Student Created Sucessfully details are : \n" + savedStudent);
				break;
			case 2:
				List<Student> stdents = studentService.getAllStudents();
				for (Student st : stdents) {
					System.out.println(st);
				}
				break;
			case 3:
				System.out.println("Enter Id of the Student you want to Update  : ");
				String id = sc.next();
				Student getStudentdata = studentService.getStudentByID(id);
				if (getStudentdata != null) {
					Student updateStudent = StudentUpdate();
					Student updatedInfo = studentService.updateStudent(id, updateStudent);
					System.out.println("Student Data Updated Sucessfully Details are : \n" + updatedInfo);
				} else {
					throw new ResourceNotFoundException("Student id doesnot Exist");
				}
				break;
			case 4:
				System.out.println("Enter Id of the Student you want to Delete  : ");
				String id2 = sc.next();
				String msg = studentService.deleteStudent(id2);
				System.out.println(msg);
				break;
			case 5:
				MainOperation.mianOps();
				break;
			}
		}
	}

//  for registering new Student
	static Student StudentInput() {
		sc.nextLine();
		System.out.println("Enter Student ID : ");
		String studentId = sc.nextLine();
		System.out.println("Enter Student First Name : ");
		String firstName = sc.nextLine();
		System.out.println("Enter Student Last Name : ");
		String Lastname = sc.nextLine();
		System.out.println("Enter Student Gender : ");
		String gender = sc.nextLine();
		System.out.println("Enter Student Email : ");
		String email = sc.nextLine();
		return new Student(studentId, firstName, Lastname, gender, email);
	}

//  for updating Student
	static Student StudentUpdate() {
		sc.nextLine();
		System.out.println("Enter Student First Name : ");
		String firstName = sc.nextLine();
		System.out.println("Enter Student Last Name : ");
		String Lastname = sc.nextLine();
		System.out.println("Enter Student Gender : ");
		String gender = sc.nextLine();
		System.out.println("Enter Student Email : ");
		String email = sc.nextLine();
		return new Student(firstName, Lastname, gender, email);
	}
//	Instructor Level operations

	public static Void instructorOperations() {
		while (true) {
			System.out.println("Press 1.Add Instructor Details\n2.Retrieve All Instructor Data\n"
					+ "3.Update Instructor Data\nPress 4.To getback to the main menu");
			int input = sc.nextInt();

			switch (input) {
			case 1:
				Instructor instructor = instructorInputs();
				Instructor ins = instructorService.createInstructor(instructor);
				System.out.println("Instructor details added successfully" + ins);
				break;

			case 4:
				MainOperation.mianOps();
			}
		}
	}

//	For Instructor Input.
	public static Instructor instructorInputs() {
		sc.nextLine();
		System.out.println("Enter InstructorID");
		String instructorId = sc.nextLine();

		System.out.println("Enter First Name");
		String firstName = sc.nextLine();

		System.out.println("Enter Last Name");
		String lastName = sc.nextLine();

		System.out.println("Enter Email");
		String email = sc.nextLine();
		return new Instructor(instructorId, firstName, lastName, email);
	}

//	for instructor update 
	public static Instructor instructorUpdate() {
		sc.nextLine();

		System.out.println("Enter First Name");
		String firstName = sc.nextLine();

		System.out.println("Enter Last Name");
		String lastName = sc.nextLine();

		System.out.println("Enter Email");
		String email = sc.nextLine();
		return new Instructor(firstName, lastName, email);
	}
//	For feedback level operations
	public static Void feedbackOperations() {
		while (true) {
			System.out.println("Press 1.Add Feedback\n2.Retrieve Feedback\n"
					+ "3.Update Feedback\nPress 4.To getback to the main menu");
			int input = sc.nextInt();

			switch (input) {
			case 1:
				Feedback feedback = provideFeedback();
				Feedback savedEntity = feedBackService.createFeedback(feedback);
				System.out.println("Your feedback has been stored successfully details are \n" + savedEntity);

			case 2:
				break;
			case 3:
				break;
			case 4:
				MainOperation.mianOps();
			}

		}
	}
//  input for providing feedback.
	public static Feedback provideFeedback() {
		sc.nextLine();
		System.out.println("Enter Instructor name");
		String instructorName = sc.nextLine();

		System.out.println("Please Provide your feedback");
		String feedback = sc.nextLine();

		System.out.println("Enter StudentID");
		String studentId = sc.nextLine();
		Student student = feedBackService.getStudent(studentId);

		return new Feedback(instructorName, feedback, student);
	}
	
//	for student Enrollment
	static Enrollment studentEnrollment() {
		sc.nextLine();
		System.out.println("Enter Enrollment Id");
		String enrollmentId = sc.nextLine();

		System.out.println("Enter Student Id");
		String studentId = sc.nextLine();

		System.out.println("Enter Course Id");
		String courseId = sc.nextLine();

		System.out.println("Enter Instructor Id");
		String instId = sc.nextLine();

		// fetch student object
		Student student = studentService.getStudentByID(studentId);

		//// fetch course object
		Course course = courseService.getCourse(courseId);

		// fetch Instructor object
		Instructor instructor = instructorService.getInstructor(instId);
		return new Enrollment(enrollmentId, student, course, instructor);
	}
//	Course level Operations
	public static Void courseOperations() {
		while (true) {
			System.out.println("Press 1.Add Course Details\n2.Retrieve All Course Data\n"
					+ "3.Update Course Data\nPress 4.To getback to the main menu");
			int input = sc.nextInt();

			switch (input) {
			case 1:
				Course course = courseInputs();
				Course crs = courseService.createCourse(course);
				System.out.println("Course details added successfully" + crs);
				break;

			case 4:
				MainOperation.mianOps();
			}
		}
	}
	
	
//	for course input
	public static Course courseInputs() {
		sc.nextLine();
		System.out.println("Enter courseID");
		String courseId = sc.nextLine();

		System.out.println("Enter course Title");
		String courseTitle = sc.nextLine();

		System.out.println("Enter credit");
		int credit = sc.nextInt();
		sc.nextLine();

		return new Course(courseId, courseTitle, credit);
	}
	
//  for getting enrollments by course id
	public static List<Enrollment> getEnrollmentByCourse() {
		System.out.println("Enter Course Id");
		String crsId = sc.nextLine();
		List<Enrollment> enroll = studentService.getEnrollmentDetailsByCourseId(crsId);
		return enroll;
	}

}
