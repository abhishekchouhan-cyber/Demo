package com.faizi;

import java.util.List;
import java.util.Scanner;

import com.faizi.entity.Enrollment;

public class MainOperation {

	static Scanner sc = new Scanner(System.in);

	public static void mianOps() {
		while (true) {
			System.out.println("Press 1.Student Details\nPress 2.Instructor Deatils"
					+ "\nPress 3.to provide feedback\nPress 4. to Enrollment\n"
					+ "Press 5.Course Details\nPress 6.to check all enrollment details based on course\n"
					+ "Press 7 for quit");
			int input = sc.nextInt();
			switch (input) {
			case 1:
				AllOperations.studentOperations();
				System.out.println("=================================");
				break;

			case 2:
				AllOperations.instructorOperations();
				System.out.println("=================================");
				break;
			case 3:
				AllOperations.feedbackOperations();
				System.out.println("=================================");
				break;
			case 4:
				Enrollment enrollment = AllOperations.studentEnrollment();
				AllOperations.studentService.studentEnrollment(enrollment);
				System.out.println("Enrollment done successfully");
				break;
			case 5:
				AllOperations.courseOperations();
				System.out.println("=================================");
				break;
			case 6:
				List<Enrollment> enroll =AllOperations.getEnrollmentByCourse();
				for (Enrollment e : enroll) {
					System.out.println(e);
				}
				break;
			case 7:
				System.exit(0);
				break;

			default:
				System.out.println("invalid input");

			}

		}
	}
}
