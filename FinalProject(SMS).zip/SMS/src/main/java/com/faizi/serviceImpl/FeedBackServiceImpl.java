package com.faizi.serviceImpl;

import com.faizi.Dao.FeedbackDao;
import com.faizi.DaoImp.FeedbackDaoImple;
import com.faizi.entity.Feedback;
import com.faizi.entity.Student;
import com.faizi.service.FeedBackService;

public class FeedBackServiceImpl implements FeedBackService {

	FeedbackDao feedBackDao=new FeedbackDaoImple();
	
	@Override
	public Student getStudent(String studentID) {
		
		return feedBackDao.getStudent(studentID);
	}

	@Override
	public Feedback createFeedback(Feedback feedback) {
		// TODO Auto-generated method stub
		return feedBackDao.createFeedback(feedback);
	}

}
