package com.faizi.serviceImpl;

import com.faizi.Dao.InstructorDao;
import com.faizi.DaoImp.InstructorDaoImple;
import com.faizi.entity.Instructor;
import com.faizi.service.InstructorService;

public class InstructorServiceImpl implements InstructorService {

	InstructorDao instructorDao=new InstructorDaoImple();
	
	@Override
	public Instructor createInstructor(Instructor instructor) {
		// TODO Auto-generated method stub
		return instructorDao.createInstructor(instructor);
	}

	@Override
	public Instructor getInstructor(String instructorId) {
		// TODO Auto-generated method stub
		return instructorDao.getInstructor(instructorId);
	}

}
