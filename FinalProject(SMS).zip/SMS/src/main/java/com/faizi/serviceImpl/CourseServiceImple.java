package com.faizi.serviceImpl;

import com.faizi.Dao.CourseDao;
import com.faizi.DaoImp.*;
import com.faizi.entity.Course;
import com.faizi.service.CourseService;

public class CourseServiceImple implements CourseService {

	CourseDao courseDao=new CourseDaoImple();
	
	@Override
	public Course createCourse(Course course) {
		// TODO Auto-generated method stub
		return courseDao.createCourse(course);
	}

	@Override
	public Course getCourse(String courseID) {
		// TODO Auto-generated method stub
		return courseDao.getCourse(courseID);
	}
	
}
