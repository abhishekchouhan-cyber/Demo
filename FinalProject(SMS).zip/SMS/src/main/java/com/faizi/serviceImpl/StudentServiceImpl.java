package com.faizi.serviceImpl;

import java.util.List;

import com.faizi.Dao.StudentDao;
import com.faizi.DaoImp.StudentDaoImpl;
import com.faizi.entity.Enrollment;
import com.faizi.entity.Student;
import com.faizi.service.StudentService;

public class StudentServiceImpl implements StudentService {

	StudentDao studentDao = new StudentDaoImpl();

	@Override
	public Student createStudent(Student student) {
		return studentDao.createStudent(student);
	}

	@Override
	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
	}

	@Override
	public Student updateStudent(String studentID, Student UpdatedStudent) {
		return studentDao.updateStudent(studentID, UpdatedStudent);
	}

	@Override
	public String deleteStudent(String studentID) {

		return studentDao.deleteStudent(studentID);
	}

	@Override
	public Student getStudentByID(String studentID) {
		return studentDao.getStudentByID(studentID);
	}

	@Override
	public List<Enrollment> getEnrollmentDetailsByCourseId(String courseId) {
			return studentDao.getEnrollmentDetailsByCourseId(courseId);
	}

	@Override
	public Enrollment studentEnrollment(Enrollment enrollment) {
		return studentDao.studentEnrollment(enrollment);
	}

}
