package com.faizi.DaoImp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.management.relation.RelationNotFoundException;
import javax.transaction.Transaction;

import org.hibernate.Session;

import com.faizi.Dao.StudentDao;
import com.faizi.Util.HibernateUtil;
import com.faizi.entity.Course;
import com.faizi.entity.Enrollment;
import com.faizi.entity.Student;
import com.faizi.exception.ResourceNotFoundException;

import org.hibernate.query.Query;

public class StudentDaoImpl implements StudentDao {

	@Override
	public Student createStudent(Student student) {
		try (Session session = HibernateUtil.getSession()) {
			session.beginTransaction();
			session.save(student);
			session.getTransaction().commit();
			return student;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	@Override
	public List<Student> getAllStudents() {

		List<Student> students = null;
		try (Session session = HibernateUtil.getSession()) {
			Query<Student> query = session.createQuery("FROM Student", Student.class);
			students = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return students;

	}

	@Override
	public Student updateStudent(String studentID, Student UpdatedStudent) {
		try (Session session = HibernateUtil.getSession()) {
			Student student = session.get(Student.class, studentID);
			session.beginTransaction();
			student.setStudentId(studentID);
			student.setLastName(UpdatedStudent.getLastName());
			student.setGender(UpdatedStudent.getGender());
			student.setEmail(UpdatedStudent.getEmail());

			session.saveOrUpdate(student);

			session.getTransaction().commit();
			return student;

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	Scanner sc = new Scanner(System.in);

	@Override
	public String deleteStudent(String studentID) {
		String msg = "null";
		try (Session session = HibernateUtil.getSession()) {
			Student student = session.get(Student.class, studentID);
			session.beginTransaction();
			System.out.println("Are you sure u want to delete it");
			String status = sc.next();
			if (status.equalsIgnoreCase("Yes")) {
				session.delete(student);
				session.getTransaction().commit();
				session.evict(student);
				msg = "Student deleted sucessfully";
			} else
				msg = "User do not want to delete this student";
		}
		return msg;
	}

	@Override
	public Student getStudentByID(String studentID) {
		try (Session session = HibernateUtil.getSession()) {
			Student student = session.get(Student.class, studentID);
			return student;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	@Override
	public List<Enrollment> getEnrollmentDetailsByCourseId(String courseId) {
		try (Session session = HibernateUtil.getSession()) {
			Course course = session.get(Course.class, courseId);
			if (course != null) {
				List<Enrollment> allenrollments = new ArrayList<>();
				Query<Enrollment> query = session.createQuery("from Enrollment");
				allenrollments = query.list();

				return allenrollments;
			} else {
				throw new ResourceNotFoundException("Course ID is not found");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	@Override
	public Enrollment studentEnrollment(Enrollment enrollment) {
		try (Session session = HibernateUtil.getSession()) {
			session.beginTransaction();
			session.save(enrollment);
			session.getTransaction().commit();
			return enrollment;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

}
