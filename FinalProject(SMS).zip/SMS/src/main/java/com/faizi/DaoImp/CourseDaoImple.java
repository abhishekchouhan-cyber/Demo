package com.faizi.DaoImp;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.faizi.Dao.CourseDao;
import com.faizi.Util.HibernateUtil;
import com.faizi.entity.Course;

public class CourseDaoImple implements CourseDao {

	@Override
	public Course createCourse(Course course) {

		try (Session session = HibernateUtil.getSession()) {

			session.beginTransaction();
			session.save(course);
			session.getTransaction().commit();
			return course;

		} catch (HibernateException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	@Override
	public Course getCourse(String courseID) {
		try (Session session = HibernateUtil.getSession()) {

			Course course = session.get(Course.class, courseID);
			return course;

		} catch (HibernateException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

}
