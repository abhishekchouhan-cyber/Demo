package com.faizi.Dao;

import com.faizi.entity.Instructor;

public interface InstructorDao {
Instructor createInstructor(Instructor instructor);	
Instructor getInstructor(String instructorId);
}

