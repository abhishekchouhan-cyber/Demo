package com.faizi.Dao;

import com.faizi.entity.Course;

public interface CourseDao {
Course createCourse(Course course);	
Course getCourse(String courseID);
}
