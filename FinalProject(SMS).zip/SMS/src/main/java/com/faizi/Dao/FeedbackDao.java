package com.faizi.Dao;

import com.faizi.entity.Feedback;
import com.faizi.entity.Student;

public interface FeedbackDao {

	Student getStudent(String studentID);

	Feedback createFeedback(Feedback feedback);

}